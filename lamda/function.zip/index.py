def lambda_handler[event, context]:

return {
    "statusCode": 200,
    "body": "URL Shortner Lambda working!"
}
